for d in *; do
  if [ -d "$d" ]; then
    convert $d/logo.png -resize 320x240 $d/logo.png
    echo "$d"
  fi
done
